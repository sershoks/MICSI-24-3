# Go Simple Web application

> Cette application ecrit en Go est une simple application web.

## How to

### Build

```shell
go build -o bin/app .
```

### Run en local

```shell
go run .
```

pour fonctionner correctement l'application a besoin d'un fichier `config.yaml` dans `/opt`
ci-dessous le template du fichier de configuration

```yaml
image: "url web d'une image"
```
